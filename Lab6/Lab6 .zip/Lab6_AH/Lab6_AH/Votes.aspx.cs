﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab6_AH
{
    public partial class Voting : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            DataView table = (DataView)SqlDataSource2.Select(DataSourceSelectArguments.Empty);
            TableRow titles = new TableRow();
            TableCell title1 = new TableCell();
            TableCell title2 = new TableCell();

            titles.Cells.Add(title1);
            titles.Cells.Add(title2);

            title1.BorderWidth = 1;
            title1.BorderColor = Color.Black;
            title1.BackColor = Color.Yellow;
            title1.Width = 100;
            title1.Text = "Candidate";

            title2.BorderWidth = 1;
            title2.BorderColor = Color.Black;
            title2.BackColor = Color.Yellow;
            title2.Width = 100;
            title2.Text = "Votes";


            Table1.Rows.Add(titles);
            foreach (DataRow row in table.Table.Rows)
            {
                TableRow r = new TableRow();
                TableCell cell1 = new TableCell();
                TableCell cell2 = new TableCell();

                r.Cells.Add(cell1);
                r.Cells.Add(cell2);


                cell1.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                cell2.BackColor = ColorTranslator.FromHtml("#FFFFFF");
 

                cell1.BorderWidth = 1;
                cell1.BorderColor = Color.Green;
                cell1.Width = 100;
                cell1.Text = row["Name"].ToString();

                cell2.BorderWidth = 1;
                cell2.BorderColor = Color.Green;
                cell2.Width = 100;
                cell2.Text = row["Votes"].ToString();


                Table1.Rows.Add(r);
            }
        }
        protected void clear_button_Click(object sender, EventArgs e)
        {
            SqlDataSource2.Update();
            Response.Redirect("/Votes.aspx");

        }
        protected void back_button_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Default.aspx");
        }
    }
}