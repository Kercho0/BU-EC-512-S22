﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Lab6_AH
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void vote_button_Click(object sender, EventArgs e)
        {
            int count_sel=0;
            foreach (ListItem item in vote_list.Items)
            {
                if (item.Selected)
                {
                    count_sel+=1;
                }
            }
            
                    int len = vote_list.Items.Count;
            int vote_indx = vote_list.SelectedIndex;
            if (vote_indx == -1)
            {
                Error.InnerHtml = "Please make a slection";
            }
            else if (count_sel > 3)
            {
                Error.InnerHtml = "Please choose no more than 3 options";
            }
            else
            {
                foreach (ListItem item in vote_list.Items)
                {
                    if (item.Selected)
                    {
                        string connect = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                        SqlConnection sqlconn = new SqlConnection(connect);
                        string query = "UPDATE Restaurants SET Votes = Votes + 1 WHERE (Id = ('" + item.Value + "'))";
                        SqlCommand sqlcommand = new SqlCommand(query, sqlconn);
                        sqlconn.Open();
                        sqlcommand.ExecuteNonQuery();
                        
                    }
                }

                Response.Redirect("/Votes.aspx");
            }

            
        }
    }
}