﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace lab5_512_AH
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void add_to_cart(object sender, EventArgs e)
        {
            if (add_cart.Text == "Add to Cart")
            {
                if (Products.SelectedValue != "")
                {
                    var cart = (List<string>)Session["Cart"];
                    cart.Add(Products.SelectedValue.ToString());
                    Session["Cart"] = cart;
                    comment.InnerHtml = "Added";
                    add_cart.Text = "Continue Shopping";
                    Products.ClearSelection();
                }
                else
                {
                    comment.InnerHtml = "Please make a Selection";
                }
            }
            else
            {
                add_cart.Text = "Add to Cart";
                comment.InnerHtml = "";
            }

        }

        protected void view_cart(object sender, EventArgs e)
        {
            var cart = (List<string>)Session["Cart"];
            Cart_List.DataSource = cart;
            Cart_List.DataBind();
            Cart_List.Visible = true;
        }

        protected void empty_cart(object sender, EventArgs e)
        {
            var cart = (List<string>)Session["Cart"];
            cart.Clear();
            Cart_List.DataSource = cart;
            Cart_List.DataBind();
            Cart_List.Visible = false;
        }
    }
}