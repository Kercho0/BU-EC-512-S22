﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab3_V2
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            outputList.Items.Clear();
            string input_text = inputString.Text;
            int input_len = input_text.Length;
            inputString.Text = "";
            List<string>  str_out = new List<string>(); 
            string curr = "";
            int num_anagrams;

            if ((input_len == 0) || (input_len > 6))
            {
                comment.InnerHtml = "Please enter a string from 1 to 6 characters";
                return;
            }
            else if (input_len == 1)
            {
                str_out.Add(input_text);
             
            }
            else if (input_len == 2)
            {
                string sub_one = input_text.Substring(0,1);
                string sub_two = input_text.Substring(1,1);
                str_out.Add(input_text);
                str_out.Add(sub_one + sub_two);
                str_out.Add(sub_two + sub_one);
 
            }
            else
            {
                str_out.Add(input_text);
                find_anagram(input_text, ref str_out, curr);
                
            }
            string[] str_out_arr;

            if (dupd.Checked) // No duplicates
            {
                str_out[0] = "placeholder";
                str_out.Add(input_text);
                string[] str_arr = str_out.ToArray();
                str_out_arr = str_arr.Distinct().ToArray();
                for (int i = 1; i < str_out_arr.Length; i++)
                {
                    outputList.Items.Add(str_out_arr[i]);
                }
                num_anagrams = (str_out_arr.Length - 1);

                comment.InnerHtml = num_anagrams + " anagrams found.";
            }
            else
            {
                str_out_arr = str_out.ToArray();
                for (int i = 1; i < str_out_arr.Length; i++)
                {
                    outputList.Items.Add(str_out_arr[i]);
                }
                num_anagrams = (str_out_arr.Length - 1);

                comment.InnerHtml = num_anagrams + " anagrams found.";
            }
           
        }

        public void find_anagram(string input_text, ref List<string> str_out, string curr)
        {
            int input_len = input_text.Length;
            for (int i=0; i<input_len; i++)
            {
                string tmp_str = input_text.Substring(i,1);
                string sub_one = input_text.Substring(0,1);
                input_text = input_text.Remove(i,1).Insert(i,sub_one);
                input_text = input_text.Remove(0,1).Insert(0,tmp_str);
                string next = input_text.Substring(1,input_text.Length-1);
                int next_len = next.Length;
                if (next_len==1)
                {
                    str_out.Add(curr+input_text);
                }
                else
                {
                    find_anagram(next,ref str_out,curr+tmp_str);
                }

            }
            
        }
    }
}