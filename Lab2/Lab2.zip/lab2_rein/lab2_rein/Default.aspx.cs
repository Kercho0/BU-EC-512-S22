﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;

namespace lab2_rein
{
    public partial class Default : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
        }
        protected void btnClear_Click(object sender, EventArgs e)
        {
            fh.Text= "";
            cent.Text= "";
            error_msg.InnerHtml = "";
        }
        protected void btnConvert_Click1(object sender, EventArgs e)
        {
            string temp_f = fh.Text;
            string temp_c = cent.Text;
            float num_temp_f;
            float num_temp_c;
            double d_temp_f;
            double d_temp_c;


            if ((temp_f == "" && temp_c == "") || (temp_c != "" && temp_f != ""))
            {
                error_msg.InnerHtml = "Enter one value.";
            }
            else
            {
                if(temp_f == "") 
                {
                    try
                    {
                        num_temp_c = float.Parse(temp_c);
                        d_temp_f = (num_temp_c * 1.8) + 32;
                        d_temp_f = Math.Round(d_temp_f, 5);
                        temp_f = d_temp_f.ToString(temp_f);
                        
                        fh.Text = temp_f;
                        error_msg.InnerHtml = "";

                    }
                    catch (Exception ex)
                    {
                        error_msg.InnerHtml = "Please enter a correct value.";
                    }
                }
                else if(temp_c == "")
                {
                    try
                    {
                        num_temp_f = float.Parse(temp_f);
                        d_temp_c = (num_temp_f - 32) * 5/9;
                        d_temp_c = Math.Round(d_temp_c, 5);
                        temp_c = d_temp_c.ToString(temp_c);
                       
                        cent.Text = temp_c;
                        error_msg.InnerHtml = "";
                    }
                    catch (Exception ex)
                    {
                        error_msg.InnerHtml = "Please enter a correct value.";
                    }

                }


            }
            



                       








                
            


          //  cent.Text = temp_f;
          //  fh.Text = temp_c;
        }
    }
}