﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab4
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            comment.InnerHtml = "";
            if (dropdownlist1.SelectedIndex == 0 | dropdownlist2.SelectedIndex == 0)
            {
                comment.InnerHtml = "Please Select Conversion Units";
            }
            else if (dropdownlist1.SelectedIndex == dropdownlist2.SelectedIndex)
            {
                comment.InnerHtml = "Please Select Two Different Units to Convert";
            }
            else
            {
                float num = -1;
                try
                {
                    // num = Convert.ToDecimal(TextBox1.Text);
                    num = float.Parse(TextBox1.Text);
                }
                catch
                {
                    comment.InnerHtml = "Please enter a valid Input";
                }
                if (num < 0)
                {
                    comment.InnerHtml = "Please enter a positive number";
                }

                else
                {

                    float base_unit = float.Parse(dropdownlist1.SelectedValue);
                    float target_unit = float.Parse(dropdownlist2.SelectedValue);
                    float conv_mid =  num* base_unit;
                    float conv_fin = conv_mid / target_unit;

                    decimal final = new decimal(conv_fin);
                    double final_d = (double)final;
                    TextBox2.Text = final_d.ToString("0.00000");
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            comment.InnerHtml = "";
            TextBox1.Text = "";
            TextBox2.Text = "";



        }
    }
}